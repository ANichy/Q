﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastecode', 'fr', {
	button: 'Coller comme code',
	title: 'Coller comme code'
});
